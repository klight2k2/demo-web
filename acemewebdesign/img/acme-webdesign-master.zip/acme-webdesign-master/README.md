# acme-webdesign
Mobile ready design template

![screenshot](https://raw.githubusercontent.com/Trailingslashes/acme-webdesign/master/img/screencapture.png)
